UAE Smart Parking - static website

Files:
- index.html: the app.

Publish with GitHub Pages:
1. Create a public repository named uae-smart-parking.
2. In the repository, choose Add file > Upload files.
3. Upload index.html and commit the change.
4. Open Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select branch main and folder /(root), then Save.
7. Wait a few minutes. Your site address will be https://YOUR-GITHUB-USERNAME.github.io/uae-smart-parking/

On iPhone:
1. Open the published address in Safari.
2. Tap Share > Add to Home Screen > Add.

Notes:
- The app saves records in the current browser on the iPhone using localStorage. Export CSV backups regularly.
- Plate OCR uses Tesseract.js loaded from a CDN, so internet is needed for OCR to load. OCR is not specialized for UAE plates and may need manual correction.
- This is a static web app, not an App Store native app. Photos are previewed for OCR and are not retained as photo files in the records.
